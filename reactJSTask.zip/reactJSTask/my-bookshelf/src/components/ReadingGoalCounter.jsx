import React, { useState } from 'react';

const ReadingGoalCounter = () => {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>Reading Goal Counter</h2>
      <p>Books Read: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)} disabled={count === 0}>
        Decrement
      </button>
      <button onClick={() => setCount(0)}>Reset</button>
    </div>
  );
};

export default ReadingGoalCounter;
