import React from 'react';
import BookList from '../components/BookList';
import ReadingGoalCounter from '../components/ReadingGoalCounter';

const Home = () => (
  <div>
    <BookList />
    <ReadingGoalCounter />
  </div>
);

export default Home;
