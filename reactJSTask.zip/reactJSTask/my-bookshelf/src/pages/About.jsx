import React from 'react';

const About = () => (
  <div>
    <h1>About MyBookshelf</h1>
    <p>This is a simple app for managing and tracking your books!</p>
  </div>
);

export default About;
